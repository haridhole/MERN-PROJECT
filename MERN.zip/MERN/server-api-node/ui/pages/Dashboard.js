import React, { Component } from 'react';
import Movies from "../src/components/movies";

class Dashboard extends Component {
    render() {
      return ( <Movies /> )
            }
    }
export default Dashboard;