const withTM = require('next-transpile-modules')(['@material-ui/core', 'react-redux']); // pass the modules you would like to see transpiled
const withSass = require('@zeit/next-sass');
const withCSS = require('@zeit/next-css');

module.exports = withCSS();
module.exports = withTM();
module.exports = withSass();
