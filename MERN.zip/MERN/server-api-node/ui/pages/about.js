import React, { Component } from 'react';
import { Button } from '@material-ui/core'; 

class About extends Component {
  state = {
    count: 0
  };
  increase = () => {
    this.setState({
      count: this.state.count + 1
    });
  };
  decrease = () => {
    this.setState({
      count: this.state.count - 1
    });
  };
  
  render() {
    return (
      <div>
        { this.state.count }
        <button onClick={this.increase}>+</button>
        <button onClick={this.decrease}>-</button>
      </div>
    )
  }
}
 
export default About;
