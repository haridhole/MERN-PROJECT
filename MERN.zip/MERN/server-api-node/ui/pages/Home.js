import React from 'react';
import './style.scss';

const Home = () => {
    return (<div className='home'>
        <h2>This is the Home Page</h2>
        <h5>Welcome</h5>
    </div>)
}

export default Home;